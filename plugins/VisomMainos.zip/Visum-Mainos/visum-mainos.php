<?php

/*
Plugin Name: Visum - Mainos Post Type
Description: Aktivoi Mainokset
Author: MainosLähde Oy
Version: 1.0
Author URI: http://www.mainoslahde.fi
*/

    ///////////////////////////////////////
	// Register Mainos Post Type
	///////////////////////////////////////

    if ( ! function_exists('mainos_post_type') ) {

    function mainos_post_type() {

        $labels = array(
            'name'                => _x( 'Mainokset', 'Post Type General Name', 'visum' ),
            'singular_name'       => _x( 'Mainos', 'Post Type Singular Name', 'visum' ),
            'menu_name'           => __( 'Mainos', 'visum' ),
            'parent_item_colon'   => __( 'Parent Item:', 'visum' ),
            'all_items'           => __( 'Kaikki mainokset', 'visum' ),
            'view_item'           => __( 'Katsele mainosta', 'visum' ),
            'add_new_item'        => __( 'Lisää uusi mainos', 'visum' ),
            'add_new'             => __( 'Lisää uusi', 'visum' ),
            'edit_item'           => __( 'Muokkaa mainosta', 'visum' ),
            'update_item'         => __( 'Päivitä mainos', 'visum' ),
            'search_items'        => __( 'Hae mainoksia', 'visum' ),
            'not_found'           => __( 'Ei löydy', 'visum' ),
            'not_found_in_trash'  => __( 'Ei löydy roskakorista', 'visum' ),
        );
        $args = array(
            'label'               => __( 'mainos_post_type', 'visum' ),
            'description'         => __( 'Etusivun mainokset', 'visum' ),
            'labels'              => $labels,
            'supports'            => array( 'title', 'editor', 'thumbnail', ),
            'taxonomies'          => array( 'category', 'post_tag' ),
            'hierarchical'        => false,
            'public'              => true,
            'show_ui'             => true,
            'show_in_menu'        => true,
            'show_in_nav_menus'   => true,
            'show_in_admin_bar'   => true,
            'menu_position'       => 5,
            'can_export'          => true,
            'has_archive'         => true,
            'exclude_from_search' => false,
            'publicly_queryable'  => true,
            'capability_type'     => 'page',
        );
        register_post_type( 'mainos', $args );

    }

    // Hook into the 'init' action
    add_action( 'init', 'mainos_post_type', 0 );
        
    }

?>