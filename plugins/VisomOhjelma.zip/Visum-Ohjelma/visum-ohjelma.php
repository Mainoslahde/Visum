<?php

/*
Plugin Name: Visum - Ohjelma Post Type
Description: Aktivoi Ohjelman
Author: MainosLähde Oy
Version: 1.0
Author URI: http://www.mainoslahde.fi
*/

    ///////////////////////////////////////
	// Register Ohjelma Post Type
	///////////////////////////////////////

    if ( ! function_exists('ohjelma_post_type') ) {

    function ohjelma_post_type() {

        $labels = array(
            'name'                => _x( 'Ohjelmat', 'Post Type General Name', 'visum' ),
            'singular_name'       => _x( 'Ohjelma', 'Post Type Singular Name', 'visum' ),
            'menu_name'           => __( 'Ohjelma', 'visum' ),
            'parent_item_colon'   => __( 'Parent Item:', 'visum' ),
            'all_items'           => __( 'Kaikki ohjelmat', 'visum' ),
            'view_item'           => __( 'Katsele ohjelmaa', 'visum' ),
            'add_new_item'        => __( 'Lisää uusi ohjelma', 'visum' ),
            'add_new'             => __( 'Lisää uusi', 'visum' ),
            'edit_item'           => __( 'Muokkaa ohjelmaa', 'visum' ),
            'update_item'         => __( 'Päivitä ohjelma', 'visum' ),
            'search_items'        => __( 'Hae ohjelma', 'visum' ),
            'not_found'           => __( 'Ei löydy', 'visum' ),
            'not_found_in_trash'  => __( 'Ei löydy roskakorista', 'visum' ),
        );
        $args = array(
            'label'               => __( 'ohjelma_post_type', 'visum' ),
            'description'         => __( 'Tulevaa ohjelma listaus', 'visum' ),
            'labels'              => $labels,
            'supports'            => array( 'title', 'editor', 'thumbnail', ),
            'taxonomies'          => array( 'category', 'post_tag' ),
            'hierarchical'        => false,
            'public'              => true,
            'show_ui'             => true,
            'show_in_menu'        => true,
            'show_in_nav_menus'   => true,
            'show_in_admin_bar'   => true,
            'menu_position'       => 5,
            'can_export'          => true,
            'has_archive'         => true,
            'exclude_from_search' => false,
            'publicly_queryable'  => true,
            'capability_type'     => 'page',
        );
        register_post_type( 'ohjelma_post_type', $args );

    }

    // Hook into the 'init' action
    add_action( 'init', 'ohjelma_post_type', 0 );
        
    }



?>